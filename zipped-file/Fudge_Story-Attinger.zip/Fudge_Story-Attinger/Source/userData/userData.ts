namespace learnjs {
    export let userData = {
        Protagonist: {
          name: 'Kazuko',
          variableTest: '',
          pointsCollected: 0,
        },
      };

      export let dataForSave = {
        nameProtagonist: "Kazuko",
        variablesDone: false,
        datatypesDone: false,
        operatorsDone: false,
        progressMeter: 0,
      }
    
}