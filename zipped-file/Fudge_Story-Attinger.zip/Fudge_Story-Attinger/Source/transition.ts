namespace learnjs {
    export let transitions = {
      clock: {
        duration: 1,
        alpha: "./Images/transitions/020.jpg",
        edge: 1
      },
      long: {
        duration: 5,
        alpha: "./Images/transitions/code.jpg",
        edge: 1
      }
    };
  }